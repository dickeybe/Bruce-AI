#pragma once
#include <GLFW/glfw3.h>

GLFWmonitor* getCurrentMonitor(GLFWwindow* window);
