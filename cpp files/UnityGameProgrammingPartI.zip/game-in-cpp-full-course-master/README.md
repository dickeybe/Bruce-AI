# Game In C++ Full Course
  
## This is the repo for my full game in C++ course.

## [YouTube video](https://youtu.be/XOs2qynEmNE).

![demo](https://github.com/meemknight/game-in-cpp-full-course/assets/36445656/bfa8bb4e-5c18-49c1-b078-81ba27561096)

Also check out how to use my [CMake](https://github.com/meemknight/cmakeSetup) setup by watching [this video](https://youtu.be/K8f73k9HM8M)!

Or check out [part 2](https://youtu.be/-PQxzNosRTo) where I quickly add a menu to the game!
